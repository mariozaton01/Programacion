package Excepciones;

public class CampoObligatorio extends Exception {
    
}
