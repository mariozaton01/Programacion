package Excepciones;

public class AñoNoValido extends Exception{
    
}
