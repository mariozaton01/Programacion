package Excepciones;

public class MesNoValido extends Exception{
    
}
